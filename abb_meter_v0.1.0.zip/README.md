# ESPHome ABB Meter external component

`abb_meter` is a configurable ESPHome external sensor platform for ABB energy
meters connected through Modbus RTU.  It is intentionally generic: every
sensor declares its Modbus register, data type, byte order and scale in YAML.

The component reads holding registers with Modbus function `0x03`.  Register
addresses are passed exactly as listed in the ABB manual (for example
`0x5B00`); do not add `40001` or subtract one.

## Repository layout

Copy the `components/abb_meter` folder to the root of
`djmuerteitm/esphome_abbmeter`, commit it, and tag the commit `v0.1.0`.

## Use from ESPHome

```yaml
external_components:
  - source: github://djmuerteitm/esphome_abbmeter@v0.1.0
    components: [abb_meter]
```

Keep the existing native `uart:` and `modbus:` blocks.  Then declare one
`abb_meter` sensor for each measurement, as shown in `example/abb_l1.yaml`.

No additional GitHub/GitLab dependency is required: the component depends
only on ESPHome's built-in `modbus` and `sensor` components.

## Supported value types

`U_WORD`, `S_WORD`, `U_DWORD`, `S_DWORD`, `U_QWORD`, and `S_QWORD`.

`register_count` is optional.  If omitted it is derived from `value_type`.
Use `swap_words: true` only when the meter's documentation specifies a
low-word-first register order.

The raw number is multiplied by `scale`; examples use `0.1`, `0.01`, or
`0.001`.
